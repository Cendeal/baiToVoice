# -*- coding: utf-8 -*-
"""
    bai public
"""

from .baidu_ai_voice import BaiVoice
